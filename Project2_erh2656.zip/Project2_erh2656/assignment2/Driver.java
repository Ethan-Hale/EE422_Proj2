/*
 * EE422C Project 2 (Mastermind) submission by
 * Ethan Hale
 * erh2656
 * Slip days used: 1
 * Fall 2023
 */

package assignment2;

import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        String[] colors = {"B", "O", "G", "P", "R", "D"};
        GameConfiguration config = new GameConfiguration(8, colors, 4 );
        SecretCodeGenerator generator = new SecretCodeGenerator(config);
        start(false, config, generator);

    }


    public static void start(Boolean isTesting, GameConfiguration config, SecretCodeGenerator generator) {

        //Initialize inout and singular scanner for whole runtime
        InputOutput inout = new InputOutput();

       //initialize variables
       boolean yesGame = true;
       String yes = new String("Y");
       String no = new String("N");

       inout.welcomeMessage();

       while(true) {
           String input = inout.newGameQuestion(); //check for Y or N for start game
           if ((input.equals(yes)) || (input.equals(no))) {
               if (input.equals(yes)) {
                   yesGame = true;
               } else if (input.equals(no)) {
                   yesGame = false;
               }
           } else {
               //throw some sort of invalid input exception for starting a game input
           }
           if(yesGame) {
               Game game = new Game(isTesting, generator, config, inout);
               game.runGame();
           } else {
                inout.closeUp(); //close scanner
                break; //end program
           }
       }


        // TODO: complete this method
		// We will call this method from our JUnit test cases.
    }
}
