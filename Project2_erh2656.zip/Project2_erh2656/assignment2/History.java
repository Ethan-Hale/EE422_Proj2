/*
 * EE422C Project 2 (Mastermind) submission by
 * Ethan Hale
 * erh2656
 * Slip days used: 1
 * Fall 2023
 */
package assignment2;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class History {

    private ArrayList<String> pastBalls; //array of past guesses

    private ArrayList<guessPin> pastPins; //array of past response pins

    private int roundCount; //# of rounds that are stored in history

    public History(){
        this.pastBalls = new ArrayList<>();
        this.pastPins = new ArrayList<>();
        this.roundCount = 0;
    }

    public void addRound(String balls, guessPin pins){ //adds a round to history
        this.pastBalls.add(balls);
        this.pastPins.add(pins);
        this.roundCount++;
    }

    public int getRounds(){
        return this.roundCount;
    } //returns how many rounds are stored
    public String getBallGroup(int index){
        return this.pastBalls.get(index);
    } //returns a ball group at the index
    public guessPin getPins(int index){
        return this.pastPins.get(index);
    } //returns response pins at the index
}
