/*
 * EE422C Project 2 (Mastermind) submission by
 * Ethan Hale
 * erh2656
 * Slip days used: 1
 * Fall 2023
 */
package assignment2;

public class guessPin {
    private int total; //total pins
    private int white; //white pin #
    private int black; //black pin #
    private int unused; //blank pins#

    public guessPin(int total, int white, int black){ //(white+black+unused) = total
        this.total = total;
        this.white = white;
        this.black = black;
        this.unused = total - (black + white);
    }

    public int getBlack(){
        return this.black;
    } //return # of black pins
    public int getWhite(){
        return this.white;
    } //return # of white pins



}
