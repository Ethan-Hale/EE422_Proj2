/*
 * EE422C Project 2 (Mastermind) submission by
 * Ethan Hale
 * erh2656
 * Slip days used: 1
 * Fall 2023
 */
package assignment2;

public class Ball {
        private String color; //color of a specific peg in a specific guess

        public Ball(String abbreviation) {
            this.color = abbreviation;
        } //sets color and creates ball

        public String getColor(){
            return color;
        } //gets color



}
