/*
 * EE422C Project 2 (Mastermind) submission by
 * Ethan Hale
 * erh2656
 * Slip days used: 1
 * Fall 2023
 */
package assignment2;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BallGroup {

    //Dynamic array of balls
    private ArrayList<Ball> balls;
    private int numBalls; //of balls in the array


    //Constructor without balls to create an empty ball list so I can add balls as I go and have a different size than 4
    public BallGroup() {
        balls = new ArrayList<Ball>();
    }

    //contructor that creates a ballgroup from a string of colors and the number of colors in the string
    //basically takes a string and turns it into an array of 1 character strings
    public BallGroup(int ballNum, String colors) {
        balls = new ArrayList<Ball>(); //new array list of balls
        for (int i = 0; i < ballNum; i++) {
            char col = colors.charAt(i); //have to isolate the character in the String input
            Ball temp = new Ball(Character.toString(col)); //make a new ball by converting the char to String  COULD DO THIS WITH substring()
            balls.add(temp); //add it to ball group
        }
        this.numBalls = ballNum;
    }

    //get ball at index
    public Ball getBall(int index) {
        if (index >= 0 && index < balls.size()) {
            return balls.get(index);
        } else {
            throw new IndexOutOfBoundsException("Index is out of bounds :(");
        }
    }

    //Method to return # of balls in BallGroup
    public int getTotalBalls() {
        return balls.size();
    }


    //should return number of balls that are in the correct place
    //only goes through balls in code so doesn't check for invalid input but shouldn't bug it
    public int cPlacementNum(BallGroup other, BallGroup code) {
        int count = 0;
        for (int i = 0; i < code.getTotalBalls(); i++) {
            if (other.getBall(i).getColor().equals(code.getBall(i).getColor())) {
                count++;
            }
        }
        return count;
    }

    //helper function for below function to make sure that I don't give double white pegs if the person guesses the same color twice in one guess
    private boolean colInArray(String color, ArrayList<String> colArray) {
        for(int i = 0;i < colArray.size();i++){
            if(colArray.get(i).equals(color)){
                return true;
            }
        }
        return false;
    }

    //check for white peg #, actual white peg number will be white peg num - black peg num

    public int cColorNum(BallGroup other, BallGroup code, GameConfiguration config){
        int count = 0;
        Map<String, Integer> guessCount = new HashMap<>();
        Map<String, Integer> codeCount = new HashMap<>(); //initialize maps

        for(int i = 0; i < config.colors.length;i++){
            guessCount.put(config.colors[i], 0); //initialize to 0
            codeCount.put(config.colors[i], 0);
        }
        for(int i = 0;i < other.numBalls;i++){ //add frequency that colors appear in the secretcode and the guess
            String guessKey = other.getBall(i).getColor();
            String codeKey = code.getBall(i).getColor();
            guessCount.put(guessKey, guessCount.get(guessKey) + 1);
            codeCount.put(codeKey, codeCount.get(codeKey) + 1);
        }
        for(int i = 0;i < config.colors.length;i++){ //compare and find how many white pins
            String key = config.colors[i];
            int guessNum = guessCount.get(key);
            int codeNum = codeCount.get(key);
            if((codeNum > 0) && (guessNum > 0)){
                if(guessNum >= codeNum){
                    count = count + codeNum;
                } else if (guessNum < codeNum){
                    count = count + guessNum;
                }
            }
        }
        return count;
    }

//checks to see if both  ballgroups are exactly the same
    public boolean equals(BallGroup other, BallGroup code){
        if(other.numBalls != code.numBalls){
            return false;
        }
        for(int i = 0; i < numBalls;i++){
            if(!(other.getBall(i).getColor().equals(code.getBall(i).getColor()))){
                return false;
            }
        }
        return true;
    }


}
