/*
 * EE422C Project 2 (Mastermind) submission by
 * Ethan Hale
 * erh2656
 * Slip days used: 1
 * Fall 2023
 */
package assignment2;
import java.util.Scanner;

public class InputOutput {

    private Scanner scanner;

    public InputOutput(){ //initialize scanner
        this.scanner = new Scanner(System.in);
    }

    public void closeUp(){ //close scanner
        scanner.close();
    }

    public Scanner getScanner(){ //TRY NOT TO USE THIS METHOD
        return this.scanner;
    }

    //Prints welcome message once per runtime
    public void welcomeMessage(){
        System.out.println("Welcome to Mastermind.");
    }

    //Prints and takes in new game question/answer
    public String newGameQuestion(){
        System.out.println("Do you want to play a new game? (Y/N):");
        String input = scanner.nextLine();
        return input;
    }

    public void testOut(String code){ //prints secret code if in test mode
        System.out.println("Secret Code: " + code);
    }

    //Prints number of guesses left at start of round
    public void numGuessOut(int remaining){
        System.out.println();
        System.out.println("You have " + remaining + " guess(es) left.");
    }

    //Prompts the player to guess and returns their guess as a string
    public String promptAndGetGuess(){
        System.out.println("Enter guess:"); //TODO should be Enter guess:
        //System.out.println();
        String guess = scanner.nextLine();
        return guess;
    }


    //Helper function for guessValidity(), checks to see if the guess contains all the right colors and capital letter, no spaces, all that
    public boolean validHelp(String guess, GameConfiguration config) {
        boolean valid = false;
        int count = 0;
        for (int i = 0; i < config.colors.length; i++) {
            for(int j = 0;j < guess.length();j++){
                if((Character.toString(guess.charAt(j)).equals( config.colors[i]))){
                    count++;
                }
            }
        }
        if (count == guess.length()) {
            valid = true;
        } else {
            valid = false;
        }
        return valid;
    }


    //checks if a guess is valid:
    //0 for history
    //1 for valid guess
    //2 for invalid guess
    public int guessValidity(String guess, GameConfiguration config){
        if(guess.equals("HISTORY")){
            return 0;
        } else if((guess.length() == config.pegNumber) && (validHelp(guess, config))){
            return 1;
        } else {
            return 2;
        }
    }

    public void printHistory(History history){ //prints history
        for(int i = 0; i < history.getRounds();i++){
            System.out.println(history.getBallGroup(i) + " -> " + history.getPins(i).getBlack() + "b_" + history.getPins(i).getWhite() + "w");
        }
    }

    public void printInvalidGuess(){ //prints invalid guess
        System.out.println("INVALID_GUESS");
    }

    public void printGuessResponse(String guess, guessPin responsePins){ //prints the guess response
        System.out.println(guess + " -> " + responsePins.getBlack() + "b_" + responsePins.getWhite() + "w");
    }

    public void printWin(){ //prints win message
        System.out.println("You win!");
        System.out.println();
    }

    public void printLoss(String secCode){ //prints loss message
        System.out.println("You lose! The pattern was " + secCode);
        System.out.println();
    }
}
