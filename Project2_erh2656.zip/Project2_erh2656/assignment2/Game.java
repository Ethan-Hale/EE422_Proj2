/*
 * EE422C Project 2 (Mastermind) submission by
 * Ethan Hale
 * erh2656
 * Slip days used: 1
 * Fall 2023
 */
package assignment2;


public class Game {

    private boolean isTesting;
    private SecretCodeGenerator generator;
    private GameConfiguration config;
    private String Code;

    private InputOutput inout;

    private History history;

    public Game(boolean isTesting, SecretCodeGenerator generator, GameConfiguration config, InputOutput inout) {
        this.isTesting = isTesting;
        this.generator = generator;
        this.config = config;
        this.Code = generator.getNewSecretCode();
        this.inout = inout;
        this.history = new History();

    }

    public void runGame(){

        BallGroup secCode = new BallGroup(config.pegNumber, Code);//initialize secret code as a ball group

        boolean GAMEOVER = false; //true if game is over
        boolean WIN = false; //true if the player has won

        if(isTesting){ //outputs secret code if in test mode
            inout.testOut(Code);
        }

        int remainingGuess = config.guessNumber;
        int roundCount = 0;
        //main loop

        while(!GAMEOVER){
            inout.numGuessOut(remainingGuess);
            String guess = inout.promptAndGetGuess(); //prompt the guess
            int guessType = inout.guessValidity(guess, config); //take in the guess and evaluate it for validity and type
                                                                //0: history; 1: valid guess; 2: invalid guess
            switch (guessType){

                case 0:

                    inout.printHistory(history);
                    break;

                case 1:

                    BallGroup guessBallGroup = new BallGroup(config.pegNumber, guess); //create new ball group object from guess

                    int b = guessBallGroup.cPlacementNum(guessBallGroup, secCode); //calculate black pins
                    int w = guessBallGroup.cColorNum(guessBallGroup, secCode, config) - b; //calculate white pins

                    guessPin responsePins = new guessPin(config.pegNumber, w, b); //output guess response

                    if(guessBallGroup.equals(guessBallGroup, secCode)){ //is true if guess and secCode are the same
                        WIN = true;
                        GAMEOVER = true;
                    }

                    inout.printGuessResponse(guess, responsePins); //output guess and pins

                    remainingGuess--; //decrease guesses remaining if valid input

                    this.history.addRound(guess, responsePins); //add guess and output to history


                    break;

                case 2:

                    inout.printInvalidGuess();
                    break;

            }
            if(remainingGuess == 0){
                GAMEOVER = true;
            }

        }
        if(WIN){
            inout.printWin();
        } else {
            inout.printLoss(Code);
        }

    }
}





